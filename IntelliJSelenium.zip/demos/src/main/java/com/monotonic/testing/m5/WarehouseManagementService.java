package com.monotonic.testing.m5;

/**
 * Created by abhijit on 09-06-2018.
 */
import com.monotonic.testing.m5.OrderMessage;

public class WarehouseManagementService {

    public static boolean sendOrder(OrderMessage orderMessage) throws WMSUnavailableException {
        throw new WMSUnavailableException("WMS is currently down for unknown reason");
    }
}
