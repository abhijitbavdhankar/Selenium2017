package com.monotonic.testing.m5.guice;

import java.util.List;

public interface SalesRepository {

    public List<Sale> loadSales();

}
