package com.monotonic.testing.m5;

/**
 * Created by abhijit on 07-06-2018.
 */
public class SalesOrderException extends Exception{

    private static final long serialVersionUID = 1110517910654342737L;

    public SalesOrderException(String message) {
        super(message);
    }

    public SalesOrderException(String message, Throwable cause) {
        super(message, cause);
    }
}
