package com.monotonic.testing.m5;

import java.util.List;

import com.monotonic.testing.m5.DataAccessException;
import com.monotonic.testing.m5.OrderEntity;
/**
 * Created by abhijit on 09-06-2018.
 */
public interface OrderDao {

    OrderEntity findById(long id) throws DataAccessException;
    int insert(OrderEntity order) throws DataAccessException;

    List<OrderEntity> findOrdersByCustomer(long customerId) throws DataAccessException;
}
