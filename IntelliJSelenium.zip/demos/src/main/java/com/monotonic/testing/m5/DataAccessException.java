package com.monotonic.testing.m5;

import java.io.Serializable;

/**
 * Created by abhijit on 09-06-2018.
 */
public class DataAccessException extends Exception {

    private static final long serialVersionUID = -1530578540919250393L;

    public DataAccessException(String arg0) {
        super(arg0);
    }

    public DataAccessException(String arg0, Throwable arg1) {
        super(arg0, arg1);
    }

    public static class ItemMessage implements Serializable {

        private static final long serialVersionUID = 1514851877383883309L;

        private String itemNumber;
        private int quantity;

        public String getItemNumber() {
            return itemNumber;
        }

        public void setItemNumber(String itemNumber) {
            this.itemNumber = itemNumber;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

    }
}
