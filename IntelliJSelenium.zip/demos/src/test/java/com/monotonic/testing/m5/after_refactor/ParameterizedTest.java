package com.monotonic.testing.m5.after_refactor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import java.util.Collection;
import java.util.Arrays;

/**
 * Created by abhijit on 26-06-2018.
 */
@RunWith(Parameterized.class)
public class ParameterizedTest {

    public String name;
    public int age;

    public ParameterizedTest(String name,int age)
    {
        this.name=name;
        this.age=age;
    }

    @Test
    public void testMethod(){
        System.out.println("Name is: "+name +" and age is: "+age);
    }

    @Parameters
    public static Collection<Object[]> parameter(){
        Object[][] pData=new Object[2][2];
        pData[0][0]="Tom";
        pData[0][1]=30;
        pData[1][0]="Harry";
        pData[1][1]=40;
        return Arrays.asList(pData);
    }
}
