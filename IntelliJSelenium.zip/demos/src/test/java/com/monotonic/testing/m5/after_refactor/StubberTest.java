package com.monotonic.testing.m5.after_refactor;

import com.monotonic.testing.m5.OrderService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.stubbing.answers.ThrowsException;
import org.mockito.stubbing.Stubber;
import org.mockito.stubbing.Answer;
import org.mockito.invocation.InvocationOnMock;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.ws.Response;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Map;

/**
 * Created by abhijit on 07-06-2018.
 */
public class StubberTest {

    private static final List<Sale> exampleSales = Arrays.asList(
            new Sale("Apples", "Cardiff", 10, 2),
            new Sale("Oranges", "Cardiff", 3, 5),
            new Sale("Bananas", "Cardiff", 6, 20),
            new Sale("Oranges", "London", 5, 7)
    );

    private static final Map<String, Integer> expectedStoreSales = new HashMap<>();
    static {
        expectedStoreSales.put("Cardiff", 155);
        expectedStoreSales.put("London", 35);
    }

    private @Mock SalesRepository stubRepository;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    public Stubber doThrow(Class<? extends Throwable> toBeThrown){
        try {
            return doAnswer(new ThrowsException(toBeThrown.newInstance()));
        }
        catch (  InstantiationException ex) {
            throw new RuntimeException(ex);
        }
        catch (  IllegalAccessException ex) {
            throw new RuntimeException(ex);
        }
    }

    private Stubber doAnswer(ThrowsException e) {
        return null;
    }

}
