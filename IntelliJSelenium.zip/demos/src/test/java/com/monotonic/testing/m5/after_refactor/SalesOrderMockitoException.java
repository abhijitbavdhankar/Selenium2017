package com.monotonic.testing.m5.after_refactor;

import org.junit.Test;
import org.mockito.MockSettings;
import org.mockito.Mockito;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.exceptions.base.MockitoException;
import java.util.LinkedList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.LinkedList;
import com.monotonic.testing.m5.SalesOrderException;
import org.mockito.stubbing.Stubber;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

/**
 * Created by abhijit on 07-06-2018.
 */
public class SalesOrderMockitoException {

    private static final List<Sale> exampleSales = Arrays.asList(
            new Sale("Apples", "Cardiff", 10, 2),
            new Sale("Oranges", "Cardiff", 3, 5),
            new Sale("Bananas", "Cardiff", 6, 20),
            new Sale("Oranges", "London", 5, 7)
    );

    private static final Map<String, Integer> expectedStoreSales = new HashMap<>();
    static {
        expectedStoreSales.put("Cardiff", 155);
        expectedStoreSales.put("London", 35);
    }

    private @Mock SalesRepository stubRepository;

    @Test
    public void shouldStoreSales() {

        //mock creation
        List mockedList = mock(List.class);

        //using mock object
        mockedList.add("one");
        mockedList.clear();

        //verification
        verify(mockedList).add("one");
        verify(mockedList).clear();
    }

    @Test
    public void shouldStoreOrderSales() {
        //You can mock concrete classes, not just interfaces
        LinkedList mockedLinkedList = mock(LinkedList.class);

        //stubbing
        when(mockedLinkedList.get(0)).thenReturn("first");
        when(mockedLinkedList.get(1)).thenThrow(new RuntimeException());
        //doThrow(new RuntimeException()).when(mockedList).clear();

        //following throws RuntimeException:
        //mockedList.clear();

        //following prints "first"
        System.out.println(mockedLinkedList.get(0));

        //following throws runtime exception
        //System.out.println(mockedList.get(1));

        //following prints "null" because get(999) was not stubbed
        System.out.println(mockedLinkedList.get(999));

        //Although it is possible to verify a stubbed invocation, usually it's just redundant
        //If your code cares what get(0) returns, then something else breaks (often even before verify() gets executed).
        //If your code doesn't care what get(0) returns, then it should not be stubbed. Not convinced? See here.
        verify(mockedLinkedList).get(0);

        //following two verifications work exactly the same - times(1) is used by default
        //verify(mockedLinkedList).add("once");
        //verify(mockedLinkedList, times(1)).add("once");
        //verify(mockedLinkedList, times(2)).add("twice");
        //verify(mockedLinkedList, times(3)).add("three times");

        //verification using never(). never() is an alias to times(0)
        verify(mockedLinkedList, never()).add("never happened");
    }

    @Test
    public void shouldStore() {
        //You can mock concrete classes, not just interfaces
        LinkedList mockedLinkedList = mock(LinkedList.class);

        //stubbing
        when(mockedLinkedList.get(0)).thenReturn("first");
        when(mockedLinkedList.get(1)).thenThrow(new RuntimeException());
        //doThrow(new RuntimeException()).when(mockedList).clear();

        //following throws RuntimeException:
        //mockedList.clear();

        //following prints "first"
        System.out.println(mockedLinkedList.get(0));

        //following throws runtime exception
        //System.out.println(mockedList.get(1));

        //following prints "null" because get(999) was not stubbed
        System.out.println(mockedLinkedList.get(999));

        //Although it is possible to verify a stubbed invocation, usually it's just redundant
        //If your code cares what get(0) returns, then something else breaks (often even before verify() gets executed).
        //If your code doesn't care what get(0) returns, then it should not be stubbed. Not convinced? See here.
        verify(mockedLinkedList).get(0);

        //following two verifications work exactly the same - times(1) is used by default
        //verify(mockedLinkedList).add("once");
        //verify(mockedLinkedList, times(1)).add("once");
        //verify(mockedLinkedList, times(2)).add("twice");
        //verify(mockedLinkedList, times(3)).add("three times");

        //verification using never(). never() is an alias to times(0)
        verify(mockedLinkedList, never()).add("never happened");
    }
}
