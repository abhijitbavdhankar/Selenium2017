package com.monotonic.testing.m5.after_refactor;
import java.net.URL;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import static org.junit.Assert.*;
import org.junit.Test;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Created by abhijit on 26-06-2018.
 */
public class SeleniumTest {

    @Test
    public void ChromeTest()
    {
        WebDriver driver;
        // declaration and instantiation of objects/variables
        //System.setProperty("webdriver.chrome.driver","E:/dev/tools/chrome.exe");
        System.setProperty("webdriver.gecko.driver", "E:/dev/tools/geckodriver.exe");
        driver = new ChromeDriver();
        driver.get("http://www.pluralsight.com");

        //WebElement searchField = driver.findElement(By.id("lst-ib"));

        ///searchField.sendKeys("pluralsight");
        //searchField.submit();
    }
}
