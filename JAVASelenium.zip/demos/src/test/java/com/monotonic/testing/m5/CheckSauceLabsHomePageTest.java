package com.monotonic.testing.m5;

import static org.junit.Assert.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.firefox.FirefoxDriverLogLevel;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.junit.Test;
/**
 * Created by abhijit on 28-06-2018.
 */
public class CheckSauceLabsHomePageTest {

    @Test
    public void site_header_is_on_home_page()
    {
        WebDriver browser;
        //Firefox's geckodriver *requires* you to specify its location.
        System.setProperty("webdriver.gecko.driver", "E:/dev/tools/geckodriver.exe");
        browser = new FirefoxDriver();
        //String baseUrl = "http://saucelabs.com";
        String expectedTitle = "Cross Browser Testing, Selenium Testing, and Mobile Testing | Sauce Labs";
        String actualTitle = "";

        browser.get("http://saucelabs.com");
        System.out.println("Application title is ============>>>>>>> "+browser.getTitle());

        actualTitle = browser.getTitle();

        if (actualTitle.contentEquals(expectedTitle)){
            System.out.println("Test Passed!");
        } else {
            System.out.println("Test Failed");
        }
        //browser.close();
        //WebElement header = browser.findElement(By.id("site-header"));
        //assertTrue((header.isDisplayed()));

        /*
                FirefoxOptions opts = new FirefoxOptions().setLogLevel(FirefoxDriverLogLevel.TRACE);
                WebDriver driver = new FirefoxDriver(opts);
                driver.get("http://www.google.com");

                Thread.sleep(10);
                System.out.println("Application title is ============>>>>>>> "+driver.getTitle());
                driver.quit();
                */
    }
}