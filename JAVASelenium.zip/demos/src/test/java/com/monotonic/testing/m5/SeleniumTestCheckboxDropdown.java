package com.monotonic.testing.m5;
import static org.junit.Assert.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.junit.Test;
/**
 * Created by abhijit on 02-07-2018.
 */
public class SeleniumTestCheckboxDropdown {

    @Test
    public void site_checkbox()
    {
        WebDriver browser;
        //Firefox's geckodriver *requires* you to specify its location.
        System.setProperty("webdriver.gecko.driver", "E:/dev/tools/geckodriver.exe");
        browser = new FirefoxDriver();

        browser.get("http://demo.guru99.com/test/login.html");

        WebElement email = browser.findElement(By.id("email"));
        WebElement password = browser.findElement(By.name("passwd"));
        email.sendKeys("abcd@gmail.com");
        password.sendKeys("abcdefghlkjl");
        System.out.println("Text Field Set");
        WebElement login = browser.findElement(By.id("SubmitLogin"));
        login.click();
        System.out.println("Login Done with Click");

        // Selecting CheckBox, Radiobutton
        browser.get("http://demo.guru99.com/test/radio.html");
        WebElement radio1 = browser.findElement(By.id("vfb-7-1"));
        WebElement radio2 = browser.findElement(By.id("vfb-7-2"));
        radio1.click();
        System.out.println("Radio Button Option 1 Selected");
        radio2.click();
        System.out.println("Radio Button Option 2 Selected");
        WebElement option1 = browser.findElement(By.id("vfb-6-0"));
        option1.click();
        // Check whether the Check box is toggled on
        if (option1.isSelected()) {
            System.out.println("Checkbox is Toggled On");
        } else {
            System.out.println("Checkbox is Toggled Off");
        }

        //Selecting Checkbox and using isSelected Method
        browser.get("http://demo.guru99.com/test/facebook.html");
        WebElement chkFBPersist = browser.findElement(By.id("persist_box"));
        for (int i=0; i<2; i++)
        {
            chkFBPersist.click ();
            System.out.println("Facebook Persists Checkbox Status is -  "+chkFBPersist.isSelected());
        }

        //Selecting Items in a Multiple SELECT elements
        browser.get("http://demo.guru99.com/test/newtours/register.php");
        Select drpCountry = new Select(browser.findElement(By.name("country")));
        drpCountry.selectByVisibleText("ANTARCTICA");

        browser.get("http://jsbin.com/osebed/2");
        Select fruits = new Select(browser.findElement(By.id("fruits")));
        fruits.selectByVisibleText("Banana");
        fruits.selectByIndex(1);

    }
}
