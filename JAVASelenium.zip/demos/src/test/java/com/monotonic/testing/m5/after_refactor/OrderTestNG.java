package com.monotonic.testing.m5.after_refactor;
import org.testng.annotations.Test;
/**
 * Created by abhijit on 26-06-2018.
 */
public class OrderTestNG {

    @Test
    public void exampleOfTestNgMaven() {
        System.out.println("This is TestNG-Maven Example");
    }

}

