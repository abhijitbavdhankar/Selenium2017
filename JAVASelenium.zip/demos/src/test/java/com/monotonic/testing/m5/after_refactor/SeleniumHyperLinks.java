package com.monotonic.testing.m5.after_refactor;
import static org.junit.Assert.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.junit.Test;
/**
 * Created by abhijit on 02-07-2018.
 */
public class SeleniumHyperLinks {

    @Test
    public void site_links()
    {
        WebDriver browser;
        //Firefox's geckodriver *requires* you to specify its location.
        System.setProperty("webdriver.gecko.driver", "E:/dev/tools/geckodriver.exe");
        browser = new FirefoxDriver();

        browser.get("http://demo.guru99.com/test/link.html");
        browser.findElement(By.linkText("click here")).click();
        System.out.println("Application title is ============>>>>>>> "+browser.getTitle());
        //browser.quit();
    }
}
