package com.monotonic.testing.m5;

/**
 * Created by abhijit on 09-06-2018.
 */
public class WMSUnavailableException extends Exception {

    private static final long serialVersionUID = -6118793265317370209L;

    public WMSUnavailableException(String message) {
        super(message);
    }
}
